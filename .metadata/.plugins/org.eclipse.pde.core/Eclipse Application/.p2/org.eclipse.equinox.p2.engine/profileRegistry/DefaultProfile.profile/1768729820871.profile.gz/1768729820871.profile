<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1768729820871'>
  <properties size='11'>
    <property name='org.eclipse.equinox.p2.cache' value='D:\osate2.10.2\workspace\.metadata\.plugins\org.eclipse.pde.core'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='D:\osate2.10.2'/>
    <property name='eclipse.touchpoint.launcherName' value='osate'/>
    <property name='org.eclipse.equinox.p2.cache.extensions' value='file:/D:/osate2.10.2/.eclipseextension|file:/D:/osate2.10.2/configuration/org.eclipse.osgi/279/data/listener_1925729951/'/>
    <property name='org.eclipse.equinox.p2.surrogate' value='true'/>
    <property name='org.eclipse.equinox.p2.cache.shared' value='D:\osate2.10.2'/>
    <property name='org.eclipse.equinox.p2.configurationFolder' value='D:\osate2.10.2\workspace\.metadata\.plugins\org.eclipse.pde.core\Eclipse Application'/>
    <property name='org.eclipse.equinox.p2.launcherConfiguration' value='D:\osate2.10.2\workspace\.metadata\.plugins\org.eclipse.pde.core\Eclipse Application\eclipse.ini.ignored'/>
  </properties>
  <units size='17'>
    <unit id='SharedProfile_DefaultProfile' version='1.0.0.1768296019734' singleton='false' generation='2'>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Shared profile'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='SharedProfile_DefaultProfile' version='1.0.0.1768296019734'/>
      </provides>
      <requires size='839'>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.openjdk.hotspot.jre.full.stripped.feature.jar&apos;, version(&apos;11.0.13.v20211116-1829&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.reqspec&apos;, version(&apos;3.0.5.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery.feature.feature.jar&apos;, version(&apos;1.2.800.v20200916-1234&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.elk.alg.mrtree&apos;, version(&apos;0.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.runtime&apos;, version(&apos;2.12.1.v20210218-2134&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.archive&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.genericeditor.extension&apos;, version(&apos;1.1.100.v20201207-1622&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.xtext.aadl2.errormodel.ui&apos;, version(&apos;6.2.2.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.doc.user&apos;, version(&apos;4.19.0.v20210303-0957&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.browser.chromium.win32.win32.x86_64&apos;, version(&apos;3.116.0.v20210302-1107&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.pptx&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn_feature.feature.jar&apos;, version(&apos;3.25.2.v20200814-0512&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ba&apos;, version(&apos;5.1.2.v20211221-1532&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.providers&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.core&apos;, version(&apos;2.3.5.v201308161310&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn_feature.feature.group&apos;, version(&apos;3.25.2.v20200814-0512&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javaewah&apos;, version(&apos;1.1.7.v20200107-0831&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.win32.x86_64&apos;, version(&apos;1.1.200.v20190812-0919&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.renderers.swt&apos;, version(&apos;0.15.0.v20201125-0918&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.elk.feature.feature.group&apos;, version(&apos;0.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;osate2&apos;, version(&apos;2.10.2.vfinal&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.xml.bind&apos;, version(&apos;2.2.0.v20201118-1845&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare&apos;, version(&apos;3.7.1300.v20210114-0707&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.feature.jar&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.scr&apos;, version(&apos;2.1.24.v20200924-1939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.builder&apos;, version(&apos;2.25.0.v20210301-0928&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.platform.runner&apos;, version(&apos;1.7.1.v20210222-1948&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.ui&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.build.source&apos;, version(&apos;3.10.1000.v20210130-0813&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.build&apos;, version(&apos;3.10.1000.v20210130-0813&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.data.adapter&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.cli&apos;, version(&apos;1.4.0.v20200417-1444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.ui&apos;, version(&apos;1.2.200.v20210118-0937&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.jface&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.ui&apos;, version(&apos;2.25.0.v20210301-0928&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.io&apos;, version(&apos;2.6.0.v20190123-2029&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications.ui&apos;, version(&apos;1.17.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.plugins.feature.feature.group&apos;, version(&apos;6.1.2.v20220120-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.directorywatcher&apos;, version(&apos;1.2.500.v20191211-1631&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.common.edit&apos;, version(&apos;2.5.0.v20210228-1829&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.feature.group&apos;, version(&apos;1.12.2.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bouncycastle.bcpg&apos;, version(&apos;1.65.0.v20200527-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.core&apos;, version(&apos;3.8.1100.v20200806-0621&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.runtime&apos;, version(&apos;1.1.4.v20210111-1007&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.core&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.servlet&apos;, version(&apos;3.1.0.v201410161800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.runtime&apos;, version(&apos;3.20.100.v20210111-0815&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui&apos;, version(&apos;1.8.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.elk.alg.layered&apos;, version(&apos;0.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.pdf&apos;, version(&apos;1.6.0.v201105071520&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.junit.runtime.source&apos;, version(&apos;3.5.1000.v20210110-1048&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.examples.feature.feature.jar&apos;, version(&apos;1.0.1.v20220206-1739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.organization.ui&apos;, version(&apos;3.0.5.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.feature.group&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.pluggable.core&apos;, version(&apos;1.2.500.v20200322-1447&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi&apos;, version(&apos;3.16.200.v20210226-1447&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit5.runtime&apos;, version(&apos;1.0.1200.v20210112-0706&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.ui&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.type.core&apos;, version(&apos;1.9.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna&apos;, version(&apos;4.5.1.v20190425-1842&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.printing&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.feature.group&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.net&apos;, version(&apos;1.3.800.v20200422-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.utils.feature.feature.group&apos;, version(&apos;2.0.1.v20210925-2005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.servlet&apos;, version(&apos;9.4.37.v20210219&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.ooxml&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.plugins.feature.feature.jar&apos;, version(&apos;6.1.2.v20220120-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.osgi.bundle.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.data.aggregation&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.base&apos;, version(&apos;4.3.200.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.notifications&apos;, version(&apos;0.3.0.v20210218-1820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.annotation&apos;, version(&apos;1.1.500.v20200407-1355&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.annotation&apos;, version(&apos;2.2.600.v20200408-1511&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm&apos;, version(&apos;5.0.1.v201404251740&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm&apos;, version(&apos;9.1.0.v20210209-1849&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.lang.unittest.feature.feature.jar&apos;, version(&apos;0.7.0.I201906281229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.util.ajax&apos;, version(&apos;9.4.37.v20210219&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk.scheduler&apos;, version(&apos;1.5.0.v20201012-1421&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.ui&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;openjfx.fxml&apos;, version(&apos;16.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.feature.feature.jar&apos;, version(&apos;1.5.701.v20201027-0550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.ui&apos;, version(&apos;1.4.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui&apos;, version(&apos;2.7.0.v20210114-1216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates.ui&apos;, version(&apos;2.25.0.v20210301-0928&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.feature.feature.jar&apos;, version(&apos;1.6.900.v20210227-0235&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.sequence&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2.modelsupport&apos;, version(&apos;6.0.1.v20210311-2251&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.dom.svg&apos;, version(&apos;1.1.0.v201011041433&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.feature.jar&apos;, version(&apos;2.3.500.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ui.templates&apos;, version(&apos;3.7.200.v20201208-0953&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.browser&apos;, version(&apos;3.6.1100.v20210118-1327&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.base&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di&apos;, version(&apos;1.7.700.v20210128-2123&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.examples&apos;, version(&apos;1.0.5.v20220206-1739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.py4j.feature.feature.group&apos;, version(&apos;0.10.9.3-bnd-B70oWw&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.core.source&apos;, version(&apos;3.14.200.v20210208-1154&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient45&apos;, version(&apos;1.0.301.v20201025-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools&apos;, version(&apos;1.2.300.v20210205-1814&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.common&apos;, version(&apos;2.10.2.vfinal&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.console&apos;, version(&apos;1.4.300.v20210211-2058&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.resources.win32.x86_64&apos;, version(&apos;3.5.400.v20190812-0909&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;py4j-java&apos;, version(&apos;0.10.9.3-bnd-LoVopg&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.formatterapp&apos;, version(&apos;1.0.0.v20200119-0748&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.feature.group&apos;, version(&apos;4.19.0.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.edit&apos;, version(&apos;2.25.0.v20210301-0928&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.source.feature.group&apos;, version(&apos;3.14.700.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;openjfx.swing&apos;, version(&apos;16.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench3&apos;, version(&apos;0.15.500.v20201021-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.debug&apos;, version(&apos;3.17.100.v20210220-1238&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.xml&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.xml&apos;, version(&apos;1.13.0.v20201124-1831&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.trace.source&apos;, version(&apos;1.2.0.v20210110-1242&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.lang&apos;, version(&apos;2.6.0.v201404270220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views&apos;, version(&apos;3.11.0.v20210111-1351&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services&apos;, version(&apos;1.9.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.repositories.feature.group&apos;, version(&apos;1.17.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.awt.util&apos;, version(&apos;1.13.0.v20201124-1832&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui&apos;, version(&apos;2.19.0.v20200917-1406&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.screenshots&apos;, version(&apos;3.25.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.log&apos;, version(&apos;1.2.1400.v20210122-1423&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.modelstats.ui&apos;, version(&apos;1.0.2.v20220120-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.core&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.xtext.aadl2.errormodel.feature.feature.group&apos;, version(&apos;9.0.2.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.platform.suite.api&apos;, version(&apos;1.7.1.v20210222-1948&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench&apos;, version(&apos;3.122.100.v20210215-1525&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.zest.layouts&apos;, version(&apos;1.1.300.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.ui.properties&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.discovery.core&apos;, version(&apos;3.25.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ui.source&apos;, version(&apos;3.13.0.v20210209-0833&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ge.doc&apos;, version(&apos;1.0.7.v20211129-1541&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.annotations&apos;, version(&apos;1.2.100.v20210211-1236&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.inject.multibindings&apos;, version(&apos;3.0.0.v201605172100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.rcp.feature.jar&apos;, version(&apos;4.19.0.v20210302-1107&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.xtext.aadl2.errormodel&apos;, version(&apos;6.2.2.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.http&apos;, version(&apos;9.4.37.v20210219&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.core.feature.feature.group&apos;, version(&apos;9.1.0.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ge.ba&apos;, version(&apos;2.0.1.v20211221-1532&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.data&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ge.feature.feature.group&apos;, version(&apos;5.2.0.v20220201-1822&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.identity.core&apos;, version(&apos;1.17.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.core&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.xml.bind&apos;, version(&apos;2.2.0.v201105210648&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.queryparser&apos;, version(&apos;6.1.0.v20161115-1612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.model&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer&apos;, version(&apos;3.2.601.v20201025-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.discovery&apos;, version(&apos;1.2.0.v20200916-1234&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.clipboard.core&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.lang.jvm.compiled&apos;, version(&apos;0.7.0.I201906281229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.transport.ecf&apos;, version(&apos;1.3.0.v20201012-1345&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.feature.jar&apos;, version(&apos;2.16.0.v20190920-0401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.printing.win32&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda&apos;, version(&apos;3.6.101.201807022034&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.config.pdf&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.lang.scriptarchive.feature.feature.group&apos;, version(&apos;0.7.0.I201906281229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.compiler.tool&apos;, version(&apos;1.2.1100.v20200916-0645&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit&apos;, version(&apos;2.13.0.v20190822-1451&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ge.errormodel.feature.feature.group&apos;, version(&apos;5.0.0.v20211129-1541&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.lowagie.text&apos;, version(&apos;2.1.7.v201004222200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.lang.scriptarchive.feature.feature.jar&apos;, version(&apos;0.7.0.I201906281229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.swt.win32&apos;, version(&apos;1.1.0.v20201119-1132&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2.instantiation&apos;, version(&apos;1.2.0.v20211215-1435&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.apache.felix.scr&apos;, version(&apos;2.10.2.vfinal&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.draw2d.ui.render&apos;, version(&apos;1.7.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.executable.feature.jar&apos;, version(&apos;3.8.1100.v20210209-1541&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.identity.feature.jar&apos;, version(&apos;1.17.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.security&apos;, version(&apos;9.4.37.v20210219&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.compatibility.state&apos;, version(&apos;1.2.300.v20210212-1137&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.ssl.feature.feature.jar&apos;, version(&apos;1.1.500.v20200812-2314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.io&apos;, version(&apos;9.4.37.v20210219&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.dependencies.birt.feature.jar&apos;, version(&apos;4.9.0.v20200203-1545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d&apos;, version(&apos;3.10.100.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.feature.jar&apos;, version(&apos;3.18.700.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.modules.jvm&apos;, version(&apos;0.7.0.I201906281232&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.parser&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.parser&apos;, version(&apos;1.13.0.v20201124-1833&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xml.serializer&apos;, version(&apos;2.7.1.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.console&apos;, version(&apos;1.1.500.v20210116-1227&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core&apos;, version(&apos;3.25.0.v20210223-0522&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.el&apos;, version(&apos;2.2.0.v201303151357&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform_root&apos;, version(&apos;4.19.0.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bouncycastle.bcprov&apos;, version(&apos;1.65.1.v20200529-1514&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui&apos;, version(&apos;2.25.0.v20210301-0928&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.platform.engine&apos;, version(&apos;1.7.1.v20210222-1948&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;py4j-python&apos;, version(&apos;0.10.9.3-bnd-2odeag&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.win32&apos;, version(&apos;3.4.400.v20200414-1247&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.feature.group&apos;, version(&apos;2.22.0.v20210114-1734&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.monitor.feature.jar&apos;, version(&apos;3.25.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.lib.macro&apos;, version(&apos;2.25.0.v20210301-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.feature.jar&apos;, version(&apos;1.12.2.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna.platform&apos;, version(&apos;4.5.1.v20190425-1842&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.formatdata&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.forms&apos;, version(&apos;3.11.100.v20210108-1139&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.inject&apos;, version(&apos;1.0.0.v20091030&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.source.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d.feature.jar&apos;, version(&apos;3.10.100.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.util&apos;, version(&apos;9.4.37.v20210219&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.analysis.architecture&apos;, version(&apos;2.0.4.v20220120-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xmlgraphics&apos;, version(&apos;2.4.0.v20200622-2037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.xtext.aadl2.errormodel.edit&apos;, version(&apos;1.0.1.v20210925-2005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;openjfx.base&apos;, version(&apos;16.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.ui.feature.feature.group&apos;, version(&apos;0.7.0.I201907161104&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.editor&apos;, version(&apos;2.17.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.ui.source&apos;, version(&apos;1.2.200.v20210118-0937&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.core&apos;, version(&apos;3.18.0.v20210222-1101&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.hamcrest.core&apos;, version(&apos;1.3.0.v20180420-1519&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2.errormodel.faulttree.generation&apos;, version(&apos;1.0.7.v20211221-1532&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.contenttype&apos;, version(&apos;3.7.900.v20210111-0918&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.lang.scriptarchive&apos;, version(&apos;0.7.0.I201906281229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.ui&apos;, version(&apos;3.14.800.v20210222-1101&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.tree.source&apos;, version(&apos;9.1.0.v20210209-1849&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.ui&apos;, version(&apos;3.7.1200.v20210206-1820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help&apos;, version(&apos;3.8.800.v20200525-0755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.lang.unittest&apos;, version(&apos;0.7.0.I201906281229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.feature.group&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator&apos;, version(&apos;1.3.600.v20200721-1308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.core.feature_root&apos;, version(&apos;9.1.0.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.xml.stream&apos;, version(&apos;1.0.1.v201004272200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.net&apos;, version(&apos;3.25.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ua.ui&apos;, version(&apos;1.2.100.v20201105-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.config.html&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.alisa.common&apos;, version(&apos;3.0.5.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.draw2d&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.doc.user&apos;, version(&apos;3.14.1100.v20210303-1700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef&apos;, version(&apos;3.11.0.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.di&apos;, version(&apos;1.3.0.v20210222-1018&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.variables&apos;, version(&apos;3.4.800.v20200120-1101&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.simpleconfigurator&apos;, version(&apos;2.10.2.vfinal&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.feature.jar&apos;, version(&apos;3.14.700.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.urischeme&apos;, version(&apos;1.1.300.v20210113-1544&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;MyPlugin&apos;, version(&apos;1.0.0.202307102140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.core.feature.feature.jar&apos;, version(&apos;9.1.0.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.launching&apos;, version(&apos;3.19.100.v20210217-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.monitor.ui&apos;, version(&apos;3.25.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace&apos;, version(&apos;1.5.1.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.tukaani.xz&apos;, version(&apos;1.8.0.v20180207-1613&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.ssl.feature.feature.jar&apos;, version(&apos;1.1.400.v20200812-2314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.feature.group&apos;, version(&apos;2.3.500.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ba.feature.feature.group&apos;, version(&apos;5.2.0.v20220120-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.lang.python.py4j.feature.feature.group&apos;, version(&apos;0.7.0.I201907020902&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator.manipulator&apos;, version(&apos;2.1.500.v20200211-1505&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2&apos;, version(&apos;4.0.2.v20210115-2013&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.elk.algorithms.feature.feature.jar&apos;, version(&apos;0.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types&apos;, version(&apos;2.25.0.v20210301-0909&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2.errormodel.analysis&apos;, version(&apos;1.1.6.v20220120-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.sequence.edit&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.feature.group&apos;, version(&apos;3.14.700.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.jsp.jasper&apos;, version(&apos;1.1.500.v20200422-1833&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.transcoder&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.transcoder&apos;, version(&apos;1.13.0.v20201124-1841&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director.app&apos;, version(&apos;1.1.600.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata&apos;, version(&apos;2.5.100.v20200908-1020&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository.tools&apos;, version(&apos;2.2.600.v20210114-1107&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ui&apos;, version(&apos;3.13.0.v20210209-0833&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf&apos;, version(&apos;3.9.101.v20201027-0547&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.jsp.jasper.registry&apos;, version(&apos;1.1.400.v20200422-1833&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.reconciler.dropins&apos;, version(&apos;1.3.500.v20210116-1855&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.launching.source&apos;, version(&apos;3.9.200.v20201208-1742&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.httpclient45.feature.feature.group&apos;, version(&apos;1.0.702.v20201025-2303&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.concurrent&apos;, version(&apos;1.2.0.v20210202-1157&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.lib&apos;, version(&apos;1.1.500.v20210209-1250&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.lang.unittest.ui&apos;, version(&apos;0.7.0.I201906281229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.jupiter.engine&apos;, version(&apos;5.7.1.v20210222-1948&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.win32.win32.x86_64&apos;, version(&apos;3.116.0.v20210302-1107&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.core&apos;, version(&apos;3.6.1000.v20201020-1107&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;cheddar-osate2&apos;, version(&apos;1.0.0.202304162013&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.jupiter.api&apos;, version(&apos;5.7.1.v20210222-1948&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.feature.group&apos;, version(&apos;2.16.0.v20190920-0401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.alisa.workbench.ui&apos;, version(&apos;3.0.5.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;osate2.executable.win32.win32.x86_64&apos;, version(&apos;2.10.2.vfinal&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.lang.python.feature.feature.group&apos;, version(&apos;0.7.0.I201906281229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.http.apache.feature.jar&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.http.apache.feature.group&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.search&apos;, version(&apos;3.13.0.v20210212-0759&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.common&apos;, version(&apos;2.5.0.v20210228-1829&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.results&apos;, version(&apos;3.0.0.v20210921-2136&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.text&apos;, version(&apos;3.17.0.v20210213-0904&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery&apos;, version(&apos;1.1.200.v20190611-1008&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apiguardian&apos;, version(&apos;1.1.0.v20190826-0900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ba.contrib&apos;, version(&apos;1.0.7.v20220120-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions&apos;, version(&apos;0.16.0.v20200507-0938&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.verify&apos;, version(&apos;4.0.4.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.util&apos;, version(&apos;3.6.0.v20210212-1137&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.elk.alg.rectpacking&apos;, version(&apos;0.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.context_feature.feature.jar&apos;, version(&apos;3.25.2.v20200828-1617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.table.ui.ext&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit.feature.group&apos;, version(&apos;2.14.0.v20190822-1451&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.reqtrace&apos;, version(&apos;2.0.3.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.thirdparty.feature.jar&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit.runtime&apos;, version(&apos;3.5.500.v20210112-0706&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.core.refactoring&apos;, version(&apos;3.11.300.v20210208-1217&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.analysis.resource.management&apos;, version(&apos;4.0.2.v20211221-1532&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingosate2.application&apos;, version(&apos;2.10.2.vfinal&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.httpclient&apos;, version(&apos;4.5.10.v20200830-2311&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director&apos;, version(&apos;2.4.700.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.artifact.repository&apos;, version(&apos;1.4.0.v20210129-2007&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.natives&apos;, version(&apos;1.3.600.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ge.feature.feature.jar&apos;, version(&apos;5.2.0.v20220201-1822&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit&apos;, version(&apos;3.11.1100.v20210203-1102&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit.feature.jar&apos;, version(&apos;2.14.0.v20190822-1451&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer&apos;, version(&apos;5.1.101.v20201025-2315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.categories.ui&apos;, version(&apos;3.0.5.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.sequence.ui&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.eclipse&apos;, version(&apos;2.2.800.v20210115-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.xtext.aadl2.properties.ui&apos;, version(&apos;4.1.2.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.feature.group&apos;, version(&apos;3.11.0.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.properties.tabbed&apos;, version(&apos;3.9.100.v20201223-1348&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.feature.group&apos;, version(&apos;2.23.0.v20200630-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.bindings&apos;, version(&apos;0.13.0.v20201119-1132&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ge.diagram&apos;, version(&apos;2.0.2.v20210113-1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications.core&apos;, version(&apos;1.17.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.ext.awt&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.genericeditor&apos;, version(&apos;1.2.0.v20210129-1224&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xml.resolver&apos;, version(&apos;1.2.0.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.beans&apos;, version(&apos;1.7.200.v20210111-0759&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2.errormodel.faulttree.edit&apos;, version(&apos;6.1.0.v20210925-2005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.launching&apos;, version(&apos;1.2.1000.v20200610-1458&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.importer&apos;, version(&apos;2.0.1.v20210312-1952&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.ui.refactoring&apos;, version(&apos;3.11.300.v20210112-0706&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.modules.platform&apos;, version(&apos;0.7.0.I201907160756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.odf&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.http.apache&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.sshd.sftp&apos;, version(&apos;2.6.0.v20210201-2003&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatechecker&apos;, version(&apos;1.2.300.v20200222-1600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.ssl&apos;, version(&apos;1.2.400.v20200611-2220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.net.win32.x86_64&apos;, version(&apos;1.1.500.v20190925-1337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.common&apos;, version(&apos;5.0.1.202103090301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench.texteditor&apos;, version(&apos;3.16.0.v20210120-0733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.equinox.launcher&apos;, version(&apos;1.6.100.v20201223-0822&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2.errormodel.help&apos;, version(&apos;1.0.3.v20211206-1639&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.core&apos;, version(&apos;3.14.200.v20210208-1154&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.xtext.aadl2.ui&apos;, version(&apos;6.2.1.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.annotations&apos;, version(&apos;1.6.600.v20191216-2352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.analyzers-smartcn&apos;, version(&apos;8.4.1.v20200122-1459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.xtext.aadl2&apos;, version(&apos;6.1.1.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.context.core&apos;, version(&apos;3.25.2.v20200828-1617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.genericeditor.extension.source&apos;, version(&apos;1.1.100.v20201207-1622&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filebuffers&apos;, version(&apos;3.6.1100.v20201029-1159&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common&apos;, version(&apos;2.22.0.v20210114-1734&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.feature.group&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;osate2.executable.win32.win32.x86_64.osate&apos;, version(&apos;2.10.2.vfinal&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.script&apos;, version(&apos;1.13.0.v20201124-1840&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.core&apos;, version(&apos;3.25.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.elk.alg.spore&apos;, version(&apos;0.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.contexts&apos;, version(&apos;1.8.400.v20191217-1710&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.feature.jar&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filesystem&apos;, version(&apos;1.7.700.v20200110-1734&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher&apos;, version(&apos;1.5.500.v20210211-1133&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.services&apos;, version(&apos;3.10.0.v20210212-1137&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt&apos;, version(&apos;3.116.0.v20210302-1107&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.commands&apos;, version(&apos;0.13.0.v20201119-1132&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.update.configurator&apos;, version(&apos;3.4.700.v20200907-1237&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.openjdk.hotspot.jre.full.stripped.feature.group&apos;, version(&apos;11.0.13.v20211116-1829&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.e3&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.databinding&apos;, version(&apos;1.12.200.v20210111-0911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tools.layout.spy&apos;, version(&apos;1.1.0.v20210110-1247&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.context_feature.feature.group&apos;, version(&apos;3.25.2.v20200828-1617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.odt&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.ods&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.quicklinks&apos;, version(&apos;1.1.0.v20200724-0708&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.table.ui&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2.errormodel.contrib&apos;, version(&apos;1.0.7.v20220120-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.odp&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation&apos;, version(&apos;1.8.0.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.modules.help&apos;, version(&apos;0.7.0.I201906281232&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.annotation&apos;, version(&apos;1.3.5.v20200909-1856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.draw2d.ui&apos;, version(&apos;1.9.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.debug.ui&apos;, version(&apos;3.12.200.v20210224-0638&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher.win32.win32.x86_64&apos;, version(&apos;1.2.100.v20210209-1541&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.el&apos;, version(&apos;2.2.0.v201303151357&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ge.ba.feature.feature.group&apos;, version(&apos;2.0.1.v20211221-1532&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.resources.ui&apos;, version(&apos;3.25.2.v20200828-1617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.wpml&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.emf.xpath&apos;, version(&apos;0.2.800.v20200609-0849&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide.application&apos;, version(&apos;1.4.0.v20210122-1423&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.i18n&apos;, version(&apos;1.13.0.v20200622-2037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.classloader&apos;, version(&apos;0.7.0.I201906281229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher&apos;, version(&apos;1.6.100.v20201223-0822&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.query&apos;, version(&apos;7.0.0.202102190929&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.lang.python&apos;, version(&apos;0.7.0.I201906281229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.thirdparty.feature.group&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ge.gef.ui&apos;, version(&apos;1.0.1.v20211129-1541&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui.editor&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.equinox.launcher.win32.win32.x86_64&apos;, version(&apos;1.2.100.v20210209-1541&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.monitor.core&apos;, version(&apos;3.25.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.user.ui.feature.group&apos;, version(&apos;2.4.1100.v20210227-0235&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.ssh.apache&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.source&apos;, version(&apos;1.2.300.v20210205-1814&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.anim&apos;, version(&apos;1.13.0.v20201130-1756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.servlet.jsp&apos;, version(&apos;2.2.0.v201112011158&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xmi&apos;, version(&apos;2.16.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.ui&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.docx&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingosate2.executable.win32.win32.x86_64&apos;, version(&apos;2.10.2.vfinal&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.elk.core.service&apos;, version(&apos;0.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsemantics.runtime.feature.feature.jar&apos;, version(&apos;1.20.0.v20210401-0731&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.tree&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.feature.jar&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.services&apos;, version(&apos;1.5.0.v20210115-1333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;openjfx.swt&apos;, version(&apos;16.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.lang.python.feature.feature.jar&apos;, version(&apos;0.7.0.I201906281229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.feature.jar&apos;, version(&apos;2.23.0.v20200630-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.httpclient&apos;, version(&apos;3.1.0.v201012070820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.ui.feature.feature.jar&apos;, version(&apos;0.7.0.I201907161104&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.event&apos;, version(&apos;1.6.0.v20210212-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.inject&apos;, version(&apos;3.0.0.v201605172100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.monitor.feature.group&apos;, version(&apos;3.25.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.webapp&apos;, version(&apos;3.10.200.v20210222-1057&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.chart.reportitem&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.identity&apos;, version(&apos;3.9.401.v20201027-0550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.ui.ext&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.edit&apos;, version(&apos;5.5.0.v20210228-1829&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ua.core&apos;, version(&apos;1.2.200.v20210208-1459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.dom&apos;, version(&apos;1.6.1.v201505192100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.dom&apos;, version(&apos;1.13.0.v20201124-1839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text.quicksearch&apos;, version(&apos;1.1.0.v20210120-0733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.elk.feature.feature.jar&apos;, version(&apos;0.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.emf&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.dnd.ide&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.ui.source&apos;, version(&apos;1.2.0.v20200813-0954&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.analysis.model&apos;, version(&apos;1.0.0.v20210408-1409&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.type.ui&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.fx.runtime.min.feature.feature.jar&apos;, version(&apos;3.7.0.202010120720&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.monitoring&apos;, version(&apos;1.2.0.v20210111-1353&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.server&apos;, version(&apos;9.4.37.v20210219&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.resources&apos;, version(&apos;3.14.0.v20210215-0934&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.gmf.runtime&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.registry&apos;, version(&apos;1.2.0.v20200614-1851&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2.instance.textual.ui&apos;, version(&apos;2.0.9.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.elk.alg.radial&apos;, version(&apos;0.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.app&apos;, version(&apos;1.5.100.v20210212-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher.eclipse&apos;, version(&apos;1.3.800.v20210205-1231&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.emf.edit&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2.instance.ui&apos;, version(&apos;1.0.10.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.providers.ide&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.core&apos;, version(&apos;1.2.200.v20210219-0944&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingosate2.config.win32.win32.x86_64&apos;, version(&apos;2.10.2.vfinal&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.emf.ui&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.providers&apos;, version(&apos;1.7.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.organization&apos;, version(&apos;3.0.5.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.elk.alg.disco&apos;, version(&apos;0.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.garbagecollector&apos;, version(&apos;1.1.400.v20200221-1022&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore&apos;, version(&apos;2.23.0.v20200630-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.emf.tx&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text&apos;, version(&apos;3.11.0.v20210203-1022&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.dependencies.birt.feature.group&apos;, version(&apos;4.9.0.v20200203-1545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.commands&apos;, version(&apos;3.9.800.v20201021-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.cheatsheets&apos;, version(&apos;3.7.200.v20210121-1039&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.core&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit&apos;, version(&apos;4.13.0.v20200204-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.jcraft.jsch&apos;, version(&apos;0.1.55.v20190404-1902&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.gmf.notation&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.chart.engine&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt&apos;, version(&apos;0.14.100.v20201217-1340&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.index.core&apos;, version(&apos;3.25.2.v20200814-0512&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.jobs&apos;, version(&apos;3.10.1100.v20210111-0815&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt.theme&apos;, version(&apos;0.13.0.v20201026-1147&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.smap&apos;, version(&apos;2.25.0.v20210301-0909&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.index.ui&apos;, version(&apos;3.25.2.v20200814-0512&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.ide.ui.feature.jar&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml&apos;, version(&apos;5.5.0.v20210228-1829&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.actions&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.doc.user&apos;, version(&apos;3.15.1000.v20210302-1902&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery.feature.feature.group&apos;, version(&apos;1.2.800.v20200916-1234&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit&apos;, version(&apos;2.16.0.v20190920-0401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.contribution.sei&apos;, version(&apos;2.0.0.v20211206-1732&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.elk.alg.common&apos;, version(&apos;0.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.openjdk.hotspot.jre.full.stripped&apos;, version(&apos;11.0.13.v20211116-1829&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro&apos;, version(&apos;3.6.100.v20210119-2223&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.ui.completions.java&apos;, version(&apos;0.7.0.I201906281229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.item.crosstab.core&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity&apos;, version(&apos;1.14.101.201807021805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.rcp.feature.feature.group&apos;, version(&apos;1.4.1100.v20210227-0235&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications.feature.jar&apos;, version(&apos;1.17.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.printing&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.feature.jar&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.jupiter.migrationsupport&apos;, version(&apos;5.7.1.v20210222-1948&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.constants&apos;, version(&apos;1.13.0.v20200622-2037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2&apos;, version(&apos;5.5.2.v20210228-1829&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tools.layout.spy.source&apos;, version(&apos;1.1.0.v20210110-1247&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.branding&apos;, version(&apos;1.3.0.v20220201-1822&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.antlr.runtime&apos;, version(&apos;3.2.0.v201101311130&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.antlr.runtime&apos;, version(&apos;4.7.2.v20200218-0804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.jarprocessor&apos;, version(&apos;1.1.700.v20210227-0235&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.feature.feature.jar&apos;, version(&apos;3.14.1702.v20201025-2315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.feature.group&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.property&apos;, version(&apos;1.8.100.v20200619-0651&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.preferences&apos;, version(&apos;3.8.200.v20210212-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsemantics.runtime.feature.feature.group&apos;, version(&apos;1.20.0.v20210401-0731&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.feature.group&apos;, version(&apos;3.18.700.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.ssh.apache.feature.group&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.ui&apos;, version(&apos;4.2.200.v20210123-1004&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.sac&apos;, version(&apos;1.3.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util.gui&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.lang.python.py4j.feature.feature.jar&apos;, version(&apos;0.7.0.I201907020902&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.jupiter.params&apos;, version(&apos;5.7.1.v20210222-1948&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.addons.swt&apos;, version(&apos;1.4.100.v20201221-2332&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.mozilla.javascript&apos;, version(&apos;1.7.5.v201504281450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.httpclient.win&apos;, version(&apos;4.5.10.v20200830-2311&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.core&apos;, version(&apos;1.3.900.v20200422-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.ui&apos;, version(&apos;1.3.1100.v20200916-0731&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.ide.ui.feature.group&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.verify.ui&apos;, version(&apos;4.0.4.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.dnd&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatesite&apos;, version(&apos;1.1.500.v20210108-0738&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications.feed&apos;, version(&apos;1.17.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.geoshapes&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.p2.reconciler.dropins&apos;, version(&apos;2.10.2.vfinal&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;openjfx.graphics.win32_64&apos;, version(&apos;16.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.lib&apos;, version(&apos;2.25.0.v20210301-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.action&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.workspace&apos;, version(&apos;4.0.2.v20210113-1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.change&apos;, version(&apos;2.14.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.runtime&apos;, version(&apos;3.7.100.v20210208-1005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds1_2.lib.source&apos;, version(&apos;1.0.500.v20210209-1250&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.zest.core&apos;, version(&apos;1.5.300.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.html&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.user.ui.feature.jar&apos;, version(&apos;2.4.1100.v20210227-0235&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ua.ui.source&apos;, version(&apos;1.2.100.v20201105-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.importer.simulink&apos;, version(&apos;1.0.6.v20220120-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.model.workbench&apos;, version(&apos;2.1.1000.v20210111-0958&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.tree.ui&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.help&apos;, version(&apos;2.10.2.vfinal&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d.feature.group&apos;, version(&apos;3.10.100.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp&apos;, version(&apos;4.19.0.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.codegen.checker&apos;, version(&apos;1.0.7.v20211206-1906&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.shared&apos;, version(&apos;2.25.0.v20210301-0928&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui.ext&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.yakindu.base.xtext.utils.jface&apos;, version(&apos;3.5.9.201911141205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.gpg.bc&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.bidi&apos;, version(&apos;1.3.100.v20210212-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.source.feature.jar&apos;, version(&apos;3.14.700.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.ui.scripts&apos;, version(&apos;0.7.0.I201906281229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository&apos;, version(&apos;2.5.0.v20201013-0853&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.elk.graph&apos;, version(&apos;0.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.core&apos;, version(&apos;3.6.800.v20200916-0645&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2.errormodel.faulttree&apos;, version(&apos;6.1.0.v20210925-2005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda.profile&apos;, version(&apos;3.4.101.201807022034&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.compress&apos;, version(&apos;1.19.0.v20200106-2343&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.properties&apos;, version(&apos;1.9.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.alisa.workbench.sdk.feature.jar&apos;, version(&apos;7.1.1.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit4.runtime&apos;, version(&apos;1.1.1500.v20210112-1623&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filesystem.win32.x86_64&apos;, version(&apos;1.4.200.v20190812-0909&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.codegen.ecore&apos;, version(&apos;2.5.2.v20210228-1829&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.ui&apos;, version(&apos;3.6.500.v20200828-1336&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.httpcore&apos;, version(&apos;4.4.12.v20200108-1212&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.ui.ext&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.source&apos;, version(&apos;9.1.0.v20210209-1849&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.lib.source&apos;, version(&apos;1.1.500.v20210209-1250&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.alisa.help&apos;, version(&apos;1.0.5.v20211206-1639&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui&apos;, version(&apos;3.119.0.v20210111-1350&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform&apos;, version(&apos;4.19.0.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.ide&apos;, version(&apos;3.15.200.v20210108-1832&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.core&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.ssl&apos;, version(&apos;1.0.200.v20200611-1836&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.feature.group&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.feature.group&apos;, version(&apos;1.13.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.resources.editor.ide&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extras.feature.feature.group&apos;, version(&apos;1.4.1100.v20210227-0235&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.identity.feature.group&apos;, version(&apos;1.17.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.opentest4j&apos;, version(&apos;1.2.0.v20190826-0900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ge.errormodel.feature.feature.jar&apos;, version(&apos;5.0.0.v20211129-1541&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin&apos;, version(&apos;2.1.400.v20191002-0702&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;openjfx.swt.feature.feature.group&apos;, version(&apos;16.0.0.202104071212&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds1_2.lib&apos;, version(&apos;1.0.500.v20210209-1250&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf&apos;, version(&apos;2.8.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk&apos;, version(&apos;1.2.0.v20210114-1214&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ui.ide&apos;, version(&apos;1.3.0.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.openjdk.hotspot.jre.full.stripped.win32.x86_64&apos;, version(&apos;11.0.13.v20211116-1829&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery.compatibility&apos;, version(&apos;1.2.0.v20200916-1234&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2.contrib&apos;, version(&apos;2.0.0.v20211206-1732&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.config.odp&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.ppt&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.dom.smil&apos;, version(&apos;1.0.1.v200903091627&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.search&apos;, version(&apos;3.25.2.v20200814-0512&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.help&apos;, version(&apos;0.7.0.I201907161104&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ide&apos;, version(&apos;2.25.0.v20210301-0843&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.dom.svg&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.dom.svg&apos;, version(&apos;1.13.0.v20201124-1839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.core.runtime&apos;, version(&apos;2.10.2.vfinal&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.swt&apos;, version(&apos;0.16.0.v20201230-1610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata.repository&apos;, version(&apos;1.3.500.v20210108-0738&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;openjfx.swt.feature.feature.jar&apos;, version(&apos;16.0.0.202104071212&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.config.ods&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;uk.co.spudsoft.birt.emitters.excel&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.config.odt&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.observable&apos;, version(&apos;1.10.0.v20200730-0848&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda.consumer&apos;, version(&apos;3.4.101.201807022034&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.event&apos;, version(&apos;2.10.2.vfinal&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.svggen&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.svggen&apos;, version(&apos;1.13.0.v20201124-1836&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.ui&apos;, version(&apos;3.25.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.config.excel&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.analyzers-common&apos;, version(&apos;6.1.0.v20161115-1612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.analyzers-common&apos;, version(&apos;8.4.1.v20200122-1459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;io.github.classgraph&apos;, version(&apos;4.8.35.v20190528-1517&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xalan&apos;, version(&apos;2.7.2.v20201124-1837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.elk.core&apos;, version(&apos;0.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde&apos;, version(&apos;3.13.1400.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.bridge&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.bridge&apos;, version(&apos;1.13.0.v20201124-1840&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp_root&apos;, version(&apos;4.19.0.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ui&apos;, version(&apos;6.3.1.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.config.pptx&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.core&apos;, version(&apos;4.0.0.v20210115-2013&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util&apos;, version(&apos;1.13.0.v20200622-2037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.geometry&apos;, version(&apos;5.0.1.202103090301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.command&apos;, version(&apos;1.1.2.v20210111-1007&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2xml&apos;, version(&apos;2.11.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.gef&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.annotations&apos;, version(&apos;7.0.0.202102190929&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.sshd.osgi&apos;, version(&apos;2.6.0.v20210201-2003&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.lib&apos;, version(&apos;2.25.0.v20210301-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.ssl.feature.feature.group&apos;, version(&apos;1.1.500.v20200812-2314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.repositories.ui&apos;, version(&apos;1.17.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.xtext.aadl2.errormodel.feature.feature.jar&apos;, version(&apos;9.0.2.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.tree.ui.ext&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2.edit&apos;, version(&apos;4.0.4.v20211221-1559&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2.errormodel.propagationgraph&apos;, version(&apos;6.2.1.v20211021-1926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.ui&apos;, version(&apos;1.3.0.v20210121-0947&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.expressions&apos;, version(&apos;3.7.100.v20210203-1000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.win32&apos;, version(&apos;1.2.800.v20200127-1343&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.jetty&apos;, version(&apos;3.7.600.v20210224-2143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.swt&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.mylyn.aadl.ui&apos;, version(&apos;1.0.7.v20220120-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.rcp.feature.feature.jar&apos;, version(&apos;1.4.1100.v20210227-0235&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.shell&apos;, version(&apos;1.1.4.v20210111-1007&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications.feature.group&apos;, version(&apos;1.17.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.feature.feature.group&apos;, version(&apos;0.7.0.I201907120558&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.edit&apos;, version(&apos;1.8.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.discovery.ui&apos;, version(&apos;3.25.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.fx.osgi&apos;, version(&apos;3.7.0.202010120720&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ba.edit&apos;, version(&apos;5.1.0.v20211005-0150&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.operations&apos;, version(&apos;2.5.1000.v20201106-1246&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.console&apos;, version(&apos;3.10.100.v20201211-1511&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.dom.events&apos;, version(&apos;3.0.0.draft20060413_v201105210656&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.ui&apos;, version(&apos;1.2.0.v20200813-0954&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.ide&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.xml&apos;, version(&apos;1.3.4.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ge.errormodel&apos;, version(&apos;2.1.0.v20211129-1541&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.acceleo.aql&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.annexsupport&apos;, version(&apos;3.2.2.v20220120-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.core&apos;, version(&apos;3.25.2.v20200814-0512&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.lang.scriptarchive.ui&apos;, version(&apos;0.7.0.I201906281229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.feature.jar&apos;, version(&apos;3.11.0.201606061308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext&apos;, version(&apos;2.25.0.v20210301-0843&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.repositories.feature.jar&apos;, version(&apos;1.17.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;openjfx.controls&apos;, version(&apos;16.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.logging&apos;, version(&apos;1.2.0.v20180409-1502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.analysis.flows&apos;, version(&apos;5.0.3.v20220120-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.repositories.core&apos;, version(&apos;1.17.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.categories&apos;, version(&apos;3.0.5.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.feature.group&apos;, version(&apos;3.25.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.geometry.convert.fx&apos;, version(&apos;5.0.0.202103090301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.httpclient45.feature.feature.jar&apos;, version(&apos;1.0.702.v20201025-2303&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.analysis.resource.budgets&apos;, version(&apos;4.0.5.v20220120-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.examples.feature.feature.group&apos;, version(&apos;1.0.1.v20220206-1739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.feature.feature.group&apos;, version(&apos;1.6.900.v20210227-0235&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.modules.feature.feature.group&apos;, version(&apos;0.7.0.I201907160756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.executable.feature.group&apos;, version(&apos;3.8.1100.v20210209-1541&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.feature.feature.group&apos;, version(&apos;3.14.1702.v20201025-2315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.feature.jar&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2.model.editor&apos;, version(&apos;5.0.3.v20211221-1532&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.themes&apos;, version(&apos;1.2.1300.v20210108-1832&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.commands.core&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.log4j&apos;, version(&apos;1.2.15.v201012070815&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.elk.algorithms.feature.feature.group&apos;, version(&apos;0.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.ui&apos;, version(&apos;1.3.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.fx.runtime.min.feature.feature.group&apos;, version(&apos;3.7.0.202010120720&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.feature.jar&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.ui&apos;, version(&apos;3.8.1200.v20210204-1156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions.supplier&apos;, version(&apos;0.15.800.v20210110-1654&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.gpg.bc.feature.group&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.alisa.workbench.sdk.feature.group&apos;, version(&apos;7.1.1.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;openjfx.swing.feature.feature.jar&apos;, version(&apos;16.0.0.202104071212&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.slf4j.api&apos;, version(&apos;1.7.30.v20200204-2150&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.registry&apos;, version(&apos;3.10.100.v20210212-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.core&apos;, version(&apos;6.1.0.v20170814-1820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.core&apos;, version(&apos;8.4.1.v20200122-1459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.elk.alg.force&apos;, version(&apos;0.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.fx&apos;, version(&apos;5.0.5.202103090301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.py4j.feature.feature.jar&apos;, version(&apos;0.10.9.3-bnd-B70oWw&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe.core&apos;, version(&apos;1.6.1.v20210218-2134&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ecore.extender&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsemantics.runtime&apos;, version(&apos;1.20.0.v20210401-0731&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.css.sac&apos;, version(&apos;1.3.1.v200903091627&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.editors&apos;, version(&apos;3.14.0.v20210215-0846&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.externaltools&apos;, version(&apos;1.1.800.v20201105-0600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.discovery.feature.jar&apos;, version(&apos;3.25.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore&apos;, version(&apos;2.25.0.v20201231-0738&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease&apos;, version(&apos;0.7.0.I201907120558&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.e3.ui&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin.equinox&apos;, version(&apos;1.1.400.v20200319-1546&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.feature.feature.group&apos;, version(&apos;1.5.701.v20201027-0550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.alisa.workbench&apos;, version(&apos;3.0.5.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extensionlocation&apos;, version(&apos;1.3.400.v20191213-1911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.vintage.engine&apos;, version(&apos;5.7.1.v20210222-1948&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.ui&apos;, version(&apos;3.22.100.v20210224-0730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.engine&apos;, version(&apos;2.6.700.v20200511-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingosate2.configuration&apos;, version(&apos;2.10.2.vfinal&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui&apos;, version(&apos;2.18.0.v20190507-0402&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench&apos;, version(&apos;1.12.100.v20210122-1731&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient45.win32&apos;, version(&apos;1.0.300.v20200816-1842&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.executable_root.win32.win32.x86_64&apos;, version(&apos;3.8.1100.v20210209-1541&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.launching&apos;, version(&apos;3.9.200.v20201208-1742&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.gef.ui&apos;, version(&apos;1.7.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.ssh.apache.feature.jar&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.jasper.glassfish&apos;, version(&apos;2.2.2.v201501141630&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.manipulation&apos;, version(&apos;1.14.300.v20210224-0730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.common&apos;, version(&apos;3.14.100.v20210212-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates&apos;, version(&apos;2.25.0.v20210301-0928&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.annotations.source&apos;, version(&apos;1.1.400.v20190929-1236&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.feature.jar&apos;, version(&apos;2.22.0.v20210114-1734&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.feature.jar&apos;, version(&apos;1.12.0.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.continuation&apos;, version(&apos;9.4.37.v20210219&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui&apos;, version(&apos;1.9.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation&apos;, version(&apos;1.10.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator&apos;, version(&apos;3.10.0.v20210111-1352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extras.feature.feature.jar&apos;, version(&apos;1.4.1100.v20210227-0235&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.workbench&apos;, version(&apos;3.25.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.rcp.feature.group&apos;, version(&apos;4.19.0.v20210302-1107&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.action&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2.errormodel.faulttree.design&apos;, version(&apos;1.1.5.v20210925-2005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface&apos;, version(&apos;3.22.100.v20210126-0831&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit.core&apos;, version(&apos;3.10.1000.v20210112-0706&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.platform.commons&apos;, version(&apos;1.7.1.v20210222-1948&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.annotations.source&apos;, version(&apos;1.2.100.v20210211-1236&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ba.feature.feature.jar&apos;, version(&apos;5.2.0.v20220120-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.externaltools&apos;, version(&apos;3.4.900.v20201105-0600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.chart.engine.extension&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ua.core.source&apos;, version(&apos;1.2.200.v20210208-1459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.core.source&apos;, version(&apos;1.2.200.v20210219-0944&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.genericeditor.diff.extension&apos;, version(&apos;1.0.600.v20200212-1524&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.ibm.icu&apos;, version(&apos;67.1.0.v20200706-1749&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ge.ba.feature.feature.jar&apos;, version(&apos;2.0.1.v20211221-1532&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.annotations&apos;, version(&apos;1.1.400.v20190929-1236&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.draw2d.ui.render.awt&apos;, version(&apos;1.8.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction&apos;, version(&apos;1.9.1.201805140824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.activation&apos;, version(&apos;1.1.0.v201211130549&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.widgets&apos;, version(&apos;1.2.800.v20201021-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.pdf&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.lang.python.py4j&apos;, version(&apos;0.7.0.I201907020902&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.ssl.feature.feature.group&apos;, version(&apos;1.1.400.v20200812-2314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.aadl2.instance.textual&apos;, version(&apos;2.0.9.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.jxpath&apos;, version(&apos;1.3.0.v200911051830&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.services&apos;, version(&apos;2.2.600.v20210110-1654&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.gpg.bc.feature.jar&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;openjfx.standard.feature.feature.group&apos;, version(&apos;16.0.0.202104071212&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.feature.jar&apos;, version(&apos;4.19.0.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ge.gef&apos;, version(&apos;1.2.0.v20220201-1822&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.synchronizer&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.feature.jar&apos;, version(&apos;4.19.0.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator.resources&apos;, version(&apos;3.8.0.v20210209-1136&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.change.edit&apos;, version(&apos;2.8.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.alisa.common.ui&apos;, version(&apos;3.0.4.v20211116-1514&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.universal&apos;, version(&apos;3.4.100.v20210108-1131&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.action.ide&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.utils&apos;, version(&apos;2.0.1.v20210925-2005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.assure&apos;, version(&apos;3.0.8.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt&apos;, version(&apos;3.18.700.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.core&apos;, version(&apos;3.5.800.v20200608-1251&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.fonts&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ui.templates.source&apos;, version(&apos;3.7.200.v20201208-0953&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.lang.unittest.feature.feature.group&apos;, version(&apos;0.7.0.I201906281229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingosate2.ini.win32.win32.x86_64&apos;, version(&apos;2.10.2.vfinal&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.context.tasks.ui&apos;, version(&apos;3.25.2.v20200828-1617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.codec&apos;, version(&apos;1.14.0.v20200818-1422&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.css&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.css&apos;, version(&apos;1.13.0.v20200622-2037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.printing.render&apos;, version(&apos;1.8.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.util&apos;, version(&apos;2.25.0.v20210301-0843&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding&apos;, version(&apos;1.10.100.v20200926-1123&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.ui&apos;, version(&apos;3.25.2.v20200814-0512&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.core&apos;, version(&apos;0.13.0.v20201015-0653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.compiler.apt&apos;, version(&apos;1.3.1200.v20200916-0645&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.feature.group&apos;, version(&apos;4.19.0.v20210303-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.doc&apos;, version(&apos;5.11.0.202103091610-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;py4j-java.source&apos;, version(&apos;0.10.9.3-bnd-LoVopg&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.junit.runtime&apos;, version(&apos;3.5.1000.v20210110-1048&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.tree&apos;, version(&apos;9.1.0.v20210209-1849&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.resources.editor&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core&apos;, version(&apos;2.6.300.v20200211-1504&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.servlet&apos;, version(&apos;1.7.0.v20210202-1229&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.analysis.binpacking&apos;, version(&apos;3.0.0.v20210113-1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen&apos;, version(&apos;2.21.0.v20200708-0547&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates.ide&apos;, version(&apos;2.25.0.v20210301-0928&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xerces&apos;, version(&apos;2.9.0.v201101211617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend&apos;, version(&apos;2.2.0.v201605260315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.net&apos;, version(&apos;1.3.1000.v20200715-0827&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.feature.jar&apos;, version(&apos;3.25.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.dialogs&apos;, version(&apos;1.2.100.v20201109-2317&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.modelstats&apos;, version(&apos;1.0.1.v20210212-1851&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.dnd&apos;, version(&apos;1.7.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.platform.launcher&apos;, version(&apos;1.7.1.v20210222-1948&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;openjfx.swing.feature.feature.group&apos;, version(&apos;16.0.0.202104071212&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.poi&apos;, version(&apos;3.9.0.v201405241750&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.table&apos;, version(&apos;6.4.2.202103091337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide&apos;, version(&apos;3.18.100.v20210122-1536&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;net.i2p.crypto.eddsa&apos;, version(&apos;0.3.0.v20181102-1323&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.xtext.aadl2.properties&apos;, version(&apos;3.1.2.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ge&apos;, version(&apos;3.0.1.v20211129-1541&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.config.docx&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.context.ui&apos;, version(&apos;3.25.2.v20200828-1617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;openjfx.standard.feature.feature.jar&apos;, version(&apos;16.0.0.202104071212&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.ant&apos;, version(&apos;1.10.9.v20201106-1946&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.discovery.feature.group&apos;, version(&apos;3.25.2.v20200813-0821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.guava&apos;, version(&apos;21.0.0.v20170206-1425&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.guava&apos;, version(&apos;27.1.0.v20190517-1946&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.guava&apos;, version(&apos;30.1.0.v20210127-2300&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.types&apos;, version(&apos;2.5.0.v20210228-1829&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.gvt&apos;, version(&apos;1.13.0.v20201124-1835&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security&apos;, version(&apos;1.3.600.v20210126-1005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.properties&apos;, version(&apos;1.8.0.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.pb&apos;, version(&apos;2.3.5.v201404071733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.modules.feature.feature.jar&apos;, version(&apos;0.7.0.I201907160756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.reqspec.ui&apos;, version(&apos;3.0.5.v20220203-1935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.ui&apos;, version(&apos;0.7.0.I201907121256&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.runtime.source&apos;, version(&apos;3.7.100.v20210208-1005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.trace&apos;, version(&apos;1.2.0.v20210110-1242&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.utils.feature.feature.jar&apos;, version(&apos;2.0.1.v20210925-2005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.pluginsupport&apos;, version(&apos;7.1.0.v20211206-1617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ease.feature.feature.jar&apos;, version(&apos;0.7.0.I201907120558&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.script.javascript&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.importexport&apos;, version(&apos;1.3.0.v20210217-1009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.alisa.contribution&apos;, version(&apos;1.0.7.v20220120-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding&apos;, version(&apos;1.5.0.v20180706-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osate.ge.swt&apos;, version(&apos;2.0.0.v20210812-1614&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ui&apos;, version(&apos;1.7.0.202008210805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.render&apos;, version(&apos;1.7.1.202004160913&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.org.eclipse.update.feature.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.birt.report.engine.emitter.config&apos;, version(&apos;4.9.0.v201905231911&apos;)]' min='0'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='org.eclipse.equinox.executable_root.win32.win32.x86_64' version='3.8.1100.v20210209-1541'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.executable_root.win32.win32.x86_64' version='3.8.1100.v20210209-1541'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.equinox.executable_root.win32.win32.x86_64' version='3.8.1100.v20210209-1541'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='2'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
        <instructions size='1'>
          <instruction key='install'>
            chmod(targetDir:${installFolder}, targetFile:launcher.exe, permissions:755);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.pde.feature.group' version='3.14.700.v20210303-1800' singleton='false'>
      <update id='org.eclipse.pde.feature.group' range='[0.0.0,3.14.700.v20210303-1800)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.pde.feature'/>
        <property name='maven-artifactId' value='org.eclipse.pde'/>
        <property name='maven-version' value='3.14.700-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2015 IBM Corporation and others.&#xA;&#xA;This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.featureName' value='Eclipse Plug-in Development Environment'/>
        <property name='df_LT.description' value='Eclipse plug-in development environment.'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.feature.group' version='3.14.700.v20210303-1800'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='26'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.feature.group' range='[3.15.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde' range='[3.13.1400.v20210303-1800,3.13.1400.v20210303-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.build' range='[3.10.1000.v20210130-0813,3.10.1000.v20210130-0813]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.core' range='[3.14.200.v20210208-1154,3.14.200.v20210208-1154]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.junit.runtime' range='[3.5.1000.v20210110-1048,3.5.1000.v20210110-1048]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.runtime' range='[3.7.100.v20210208-1005,3.7.100.v20210208-1005]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ui' range='[3.13.0.v20210209-0833,3.13.0.v20210209-0833]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.doc.user' range='[3.14.1100.v20210303-1700,3.14.1100.v20210303-1700]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ui.templates' range='[3.7.200.v20201208-0953,3.7.200.v20201208-0953]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm' range='[9.1.0.v20210209-1849,9.1.0.v20210209-1849]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm.tree' range='[9.1.0.v20210209-1849,9.1.0.v20210209-1849]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.api.tools' range='[1.2.300.v20210205-1814,1.2.300.v20210205-1814]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.api.tools.annotations' range='[1.1.400.v20190929-1236,1.1.400.v20190929-1236]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.api.tools.ui' range='[1.2.200.v20210118-0937,1.2.200.v20210118-0937]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds.core' range='[1.2.200.v20210219-0944,1.2.200.v20210219-0944]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds.ui' range='[1.2.0.v20200813-0954,1.2.0.v20200813-0954]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.launching' range='[3.9.200.v20201208-1742,3.9.200.v20201208-1742]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ua.core' range='[1.2.200.v20210208-1459,1.2.200.v20210208-1459]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ua.ui' range='[1.2.100.v20201105-1530,1.2.100.v20201105-1530]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.trace' range='[1.2.0.v20210110-1242,1.2.0.v20210110-1242]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds.annotations' range='[1.2.100.v20210211-1236,1.2.100.v20210211-1236]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.genericeditor.extension' range='[1.1.100.v20201207-1622,1.1.100.v20201207-1622]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds.lib' range='[1.1.500.v20210209-1250,1.1.500.v20210209-1250]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds1_2.lib' range='[1.0.500.v20210209-1250,1.0.500.v20210209-1250]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tools.layout.spy' range='[1.1.0.v20210110-1247,1.1.0.v20210110-1247]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.feature.jar' range='[3.14.700.v20210303-1800,3.14.700.v20210303-1800]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.pde.source.feature.group' version='3.14.700.v20210303-1800' singleton='false'>
      <update id='org.eclipse.pde.source.feature.group' range='[0.0.0,3.14.700.v20210303-1800)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.pde.feature'/>
        <property name='maven-artifactId' value='org.eclipse.pde'/>
        <property name='maven-version' value='3.14.700-SNAPSHOT'/>
        <property name='maven-classifier' value='sources-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2015 IBM Corporation and others.&#xA;&#xA;This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.featureName' value='Eclipse PDE Plug-in Developer Resources'/>
        <property name='df_LT.description' value='Eclipse plug-in development environment, including documentation and source code zips.'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.source.feature.group' version='3.14.700.v20210303-1800'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='24'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.feature.group' range='[3.14.700.v20210303-1800,3.14.700.v20210303-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.build.source' range='[3.10.1000.v20210130-0813,3.10.1000.v20210130-0813]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.core.source' range='[3.14.200.v20210208-1154,3.14.200.v20210208-1154]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.junit.runtime.source' range='[3.5.1000.v20210110-1048,3.5.1000.v20210110-1048]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.runtime.source' range='[3.7.100.v20210208-1005,3.7.100.v20210208-1005]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ui.source' range='[3.13.0.v20210209-0833,3.13.0.v20210209-0833]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ui.templates.source' range='[3.7.200.v20201208-0953,3.7.200.v20201208-0953]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm.source' range='[9.1.0.v20210209-1849,9.1.0.v20210209-1849]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm.tree.source' range='[9.1.0.v20210209-1849,9.1.0.v20210209-1849]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.api.tools.source' range='[1.2.300.v20210205-1814,1.2.300.v20210205-1814]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.api.tools.annotations.source' range='[1.1.400.v20190929-1236,1.1.400.v20190929-1236]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.api.tools.ui.source' range='[1.2.200.v20210118-0937,1.2.200.v20210118-0937]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds.core.source' range='[1.2.200.v20210219-0944,1.2.200.v20210219-0944]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds.ui.source' range='[1.2.0.v20200813-0954,1.2.0.v20200813-0954]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.launching.source' range='[3.9.200.v20201208-1742,3.9.200.v20201208-1742]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ua.core.source' range='[1.2.200.v20210208-1459,1.2.200.v20210208-1459]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ua.ui.source' range='[1.2.100.v20201105-1530,1.2.100.v20201105-1530]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.trace.source' range='[1.2.0.v20210110-1242,1.2.0.v20210110-1242]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds.annotations.source' range='[1.2.100.v20210211-1236,1.2.100.v20210211-1236]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.genericeditor.extension.source' range='[1.1.100.v20201207-1622,1.1.100.v20201207-1622]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds.lib.source' range='[1.1.500.v20210209-1250,1.1.500.v20210209-1250]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds1_2.lib.source' range='[1.0.500.v20210209-1250,1.0.500.v20210209-1250]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tools.layout.spy.source' range='[1.1.0.v20210110-1247,1.1.0.v20210110-1247]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.source.feature.jar' range='[3.14.700.v20210303-1800,3.14.700.v20210303-1800]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.platform_root' version='4.19.0.v20210303-1800'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform_root' version='4.19.0.v20210303-1800'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.platform_root' version='4.19.0.v20210303-1800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.rcp_root' version='4.19.0.v20210303-1800'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp_root' version='4.19.0.v20210303-1800'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.rcp_root' version='4.19.0.v20210303-1800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osate.alisa.workbench.sdk.feature.group' version='7.1.1.v20220203-1935' singleton='false'>
      <update id='org.osate.alisa.workbench.sdk.feature.group' range='[0.0.0,7.1.1.v20220203-1935)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='ALISA Requirement Specification and Verification'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.osate'/>
        <property name='maven-artifactId' value='org.osate.alisa.workbench.sdk'/>
        <property name='maven-version' value='7.1.1-SNAPSHOT'/>
        <property name='df_LT.license' value='Copyright (c) 2004-2021 Carnegie Mellon University and others. (see Contributors file).&#xA;All Rights Reserved.&#xA;&#xA;NO WARRANTY. ALL MATERIAL IS FURNISHED ON AN &quot;AS-IS&quot; BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY&#xA;KIND, EITHER EXPRESSED OR IMPLIED, AS TO ANY MATTER INCLUDING, BUT NOT LIMITED TO, WARRANTY OF FITNESS FOR PURPOSE&#xA;OR MERCHANTABILITY, EXCLUSIVITY, OR RESULTS OBTAINED FROM USE OF THE MATERIAL. CARNEGIE MELLON UNIVERSITY DOES NOT&#xA;MAKE ANY WARRANTY OF ANY KIND WITH RESPECT TO FREEDOM FROM PATENT, TRADEMARK, OR COPYRIGHT INFRINGEMENT.&#xA;&#xA;This program and the accompanying materials are made available under the terms of the Eclipse Public License 2.0&#xA;which is available at https://www.eclipse.org/legal/epl-2.0/&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Created, in part, with funding and support from the United States Government. (see Acknowledgments file).&#xA;&#xA;This program includes and/or can make use of certain third party source code, object code, documentation and other&#xA;files (&quot;Third Party Software&quot;). The Third Party Software that is used by this program is dependent upon your system&#xA;configuration. By using this program, You agree to comply with any and all relevant Third Party Software terms and&#xA;conditions contained in any such Third Party Software or separate license file distributed with such Third Party&#xA;Software. The parties who own the Third Party Software (&quot;Third Party Licensors&quot;) are intended third party benefici-&#xA;aries to this license with respect to the terms applicable to their Third Party Software. Third Party Software li-&#xA;censes only apply to the Third Party Software and not any other portion of this program or this program as a whole.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osate.alisa.workbench.sdk.feature.group' version='7.1.1.v20220203-1935'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.alisa.workbench' range='[3.0.5.v20220203-1935,3.0.5.v20220203-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.alisa.workbench.ui' range='[3.0.5.v20220203-1935,3.0.5.v20220203-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.verify' range='[4.0.4.v20220203-1935,4.0.4.v20220203-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.verify.ui' range='[4.0.4.v20220203-1935,4.0.4.v20220203-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.assure' range='[3.0.8.v20220203-1935,3.0.8.v20220203-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.results' range='[3.0.0.v20210921-2136,3.0.0.v20210921-2136]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.reqspec' range='[3.0.5.v20220203-1935,3.0.5.v20220203-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.reqspec.ui' range='[3.0.5.v20220203-1935,3.0.5.v20220203-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.alisa.common' range='[3.0.5.v20220203-1935,3.0.5.v20220203-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.alisa.common.ui' range='[3.0.4.v20211116-1514,3.0.4.v20211116-1514]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.categories' range='[3.0.5.v20220203-1935,3.0.5.v20220203-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.categories.ui' range='[3.0.5.v20220203-1935,3.0.5.v20220203-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.organization' range='[3.0.5.v20220203-1935,3.0.5.v20220203-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.organization.ui' range='[3.0.5.v20220203-1935,3.0.5.v20220203-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.reqtrace' range='[2.0.3.v20220203-1935,2.0.3.v20220203-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.alisa.help' range='[1.0.5.v20211206-1639,1.0.5.v20211206-1639]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.alisa.contribution' range='[1.0.7.v20220120-2009,1.0.7.v20220120-2009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.alisa.workbench.sdk.feature.jar' range='[7.1.1.v20220203-1935,7.1.1.v20220203-1935]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        Copyright (c) 2004-2021 Carnegie Mellon University. All rights reserved.
      </copyright>
    </unit>
    <unit id='org.osate.ba.feature.feature.group' version='5.2.0.v20220120-2009' singleton='false'>
      <update id='org.osate.ba.feature.feature.group' range='[0.0.0,5.2.0.v20220120-2009)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='AADL-BA-FrontEnd'/>
        <property name='org.eclipse.equinox.p2.description' value='TELECOM Paristech AADL V2 Behavior Model Annex editor for OSATE2.&#xA;Behavior Model Annex 0.94 compliant.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://aadl.telecom-paristech.fr/'/>
        <property name='org.eclipse.equinox.p2.provider' value='TELECOM ParisTech'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.osate'/>
        <property name='maven-artifactId' value='org.osate.ba.feature'/>
        <property name='maven-version' value='5.2.0-SNAPSHOT'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osate.ba.feature.feature.group' version='5.2.0.v20220120-2009'/>
      </provides>
      <requires size='12'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2.modelsupport' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.annexsupport' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.xtext.aadl2.properties' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.utils' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.edit' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2.edit' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ba' range='[5.1.2.v20211221-1532,5.1.2.v20211221-1532]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ba.edit' range='[5.1.0.v20211005-0150,5.1.0.v20211005-0150]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ba.contrib' range='[1.0.7.v20220120-2009,1.0.7.v20220120-2009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ba.feature.feature.jar' range='[5.2.0.v20220120-2009,5.2.0.v20220120-2009]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.eclipse.org/org/documents/epl-v10.ph' url='http://www.eclipse.org/org/documents/epl-v10.ph'>
          This program is free software: you can redistribute it and/or modify  it under the terms of the Eclipse Public License as published by Eclipse, either version 1.0 of the License, or (at your option) any later version.&#xA;This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the Eclipse Public License for more details.&#xA;You should have received a copy of the Eclipse Public License along with this program. If not, see http://www.eclipse.org/org/documents/epl-v10.ph
        </license>
      </licenses>
      <copyright uri='http://aadl.telecom-paristech.fr/' url='http://aadl.telecom-paristech.fr/'>
        AADL-BA-FrontEnd&#xA;Copyright © 2011 TELECOM ParisTech and CNRS&#xA;TELECOM ParisTech/LTCI
      </copyright>
    </unit>
    <unit id='org.osate.core.feature_root' version='9.1.0.v20220203-1935'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osate.core.feature_root' version='9.1.0.v20220203-1935'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.osate.core.feature_root' version='9.1.0.v20220203-1935'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osate.examples.feature.feature.group' version='1.0.1.v20220206-1739' singleton='false'>
      <update id='org.osate.examples.feature.feature.group' range='[0.0.0,1.0.1.v20220206-1739)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='AADL Example Projects'/>
        <property name='org.eclipse.equinox.p2.description' value='This feature provides a number of example AADL projects.'/>
        <property name='org.eclipse.equinox.p2.provider' value='CMU SEI'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.osate'/>
        <property name='maven-artifactId' value='org.osate.examples.feature'/>
        <property name='maven-version' value='1.0.1-SNAPSHOT'/>
        <property name='df_LT.license' value='Copyright (c) 2004-2021 Carnegie Mellon University and others. (see Contributors file).&#xA;All Rights Reserved.&#xA;&#xA;NO WARRANTY. ALL MATERIAL IS FURNISHED ON AN &quot;AS-IS&quot; BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY&#xA;KIND, EITHER EXPRESSED OR IMPLIED, AS TO ANY MATTER INCLUDING, BUT NOT LIMITED TO, WARRANTY OF FITNESS FOR PURPOSE&#xA;OR MERCHANTABILITY, EXCLUSIVITY, OR RESULTS OBTAINED FROM USE OF THE MATERIAL. CARNEGIE MELLON UNIVERSITY DOES NOT&#xA;MAKE ANY WARRANTY OF ANY KIND WITH RESPECT TO FREEDOM FROM PATENT, TRADEMARK, OR COPYRIGHT INFRINGEMENT.&#xA;&#xA;This program and the accompanying materials are made available under the terms of the Eclipse Public License 2.0&#xA;which is available at https://www.eclipse.org/legal/epl-2.0/&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Created, in part, with funding and support from the United States Government. (see Acknowledgments file).&#xA;&#xA;This program includes and/or can make use of certain third party source code, object code, documentation and other&#xA;files (&quot;Third Party Software&quot;). The Third Party Software that is used by this program is dependent upon your system&#xA;configuration. By using this program, You agree to comply with any and all relevant Third Party Software terms and&#xA;conditions contained in any such Third Party Software or separate license file distributed with such Third Party&#xA;Software. The parties who own the Third Party Software (&quot;Third Party Licensors&quot;) are intended third party benefici-&#xA;aries to this license with respect to the terms applicable to their Third Party Software. Third Party Software li-&#xA;censes only apply to the Third Party Software and not any other portion of this program or this program as a whole.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osate.examples.feature.feature.group' version='1.0.1.v20220206-1739'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.examples' range='[1.0.5.v20220206-1739,1.0.5.v20220206-1739]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.examples.feature.feature.jar' range='[1.0.1.v20220206-1739,1.0.1.v20220206-1739]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        Copyright (c) 2004-2021 by Carnegie Mellon University. All rights reserved.
      </copyright>
    </unit>
    <unit id='org.osate.ge.ba.feature.feature.group' version='2.0.1.v20211221-1532' singleton='false'>
      <update id='org.osate.ge.ba.feature.feature.group' range='[0.0.0,2.0.1.v20211221-1532)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='OSATE Graphical Editor Behavior Annex'/>
        <property name='org.eclipse.equinox.p2.description' value='OSATE Graphical Editor Behavior Annex Support'/>
        <property name='org.eclipse.equinox.p2.provider' value='The University of Alabama in Huntsville'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.osate'/>
        <property name='maven-artifactId' value='org.osate.ge.ba.feature'/>
        <property name='maven-version' value='2.0.1-SNAPSHOT'/>
        <property name='df_LT.license' value='Copyright (c) 2004-2021 Carnegie Mellon University and others. (see Contributors file).&#xA;All Rights Reserved.&#xA;&#xA;NO WARRANTY. ALL MATERIAL IS FURNISHED ON AN &quot;AS-IS&quot; BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY&#xA;KIND, EITHER EXPRESSED OR IMPLIED, AS TO ANY MATTER INCLUDING, BUT NOT LIMITED TO, WARRANTY OF FITNESS FOR PURPOSE&#xA;OR MERCHANTABILITY, EXCLUSIVITY, OR RESULTS OBTAINED FROM USE OF THE MATERIAL. CARNEGIE MELLON UNIVERSITY DOES NOT&#xA;MAKE ANY WARRANTY OF ANY KIND WITH RESPECT TO FREEDOM FROM PATENT, TRADEMARK, OR COPYRIGHT INFRINGEMENT.&#xA;&#xA;This program and the accompanying materials are made available under the terms of the Eclipse Public License 2.0&#xA;which is available at https://www.eclipse.org/legal/epl-2.0/&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Created, in part, with funding and support from the United States Government. (see Acknowledgments file).&#xA;&#xA;This program includes and/or can make use of certain third party source code, object code, documentation and other&#xA;files (&quot;Third Party Software&quot;). The Third Party Software that is used by this program is dependent upon your system&#xA;configuration. By using this program, You agree to comply with any and all relevant Third Party Software terms and&#xA;conditions contained in any such Third Party Software or separate license file distributed with such Third Party&#xA;Software. The parties who own the Third Party Software (&quot;Third Party Licensors&quot;) are intended third party benefici-&#xA;aries to this license with respect to the terms applicable to their Third Party Software. Third Party Software li-&#xA;censes only apply to the Third Party Software and not any other portion of this program or this program as a whole.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge.ba.feature.feature.group' version='2.0.1.v20211221-1532'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ba' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views.properties.tabbed' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge.swt' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ui' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.xtext.aadl2.ui' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ui' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge.ba' range='[2.0.1.v20211221-1532,2.0.1.v20211221-1532]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge.ba.feature.feature.jar' range='[2.0.1.v20211221-1532,2.0.1.v20211221-1532]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        Copyright (c) 2004-2021 Carnegie Mellon University and others. (see Contributors file).
      </copyright>
    </unit>
    <unit id='org.osate.ge.errormodel.feature.feature.group' version='5.0.0.v20211129-1541' singleton='false'>
      <update id='org.osate.ge.errormodel.feature.feature.group' range='[0.0.0,5.0.0.v20211129-1541)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='OSATE Graphical Editor EMV2'/>
        <property name='org.eclipse.equinox.p2.description' value='OSATE Graphical Editor Error Model Support'/>
        <property name='org.eclipse.equinox.p2.provider' value='The University of Alabama in Huntsville'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.osate'/>
        <property name='maven-artifactId' value='org.osate.ge.errormodel.feature'/>
        <property name='maven-version' value='5.0.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Copyright (c) 2004-2021 Carnegie Mellon University and others. (see Contributors file).&#xA;All Rights Reserved.&#xA;&#xA;NO WARRANTY. ALL MATERIAL IS FURNISHED ON AN &quot;AS-IS&quot; BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY&#xA;KIND, EITHER EXPRESSED OR IMPLIED, AS TO ANY MATTER INCLUDING, BUT NOT LIMITED TO, WARRANTY OF FITNESS FOR PURPOSE&#xA;OR MERCHANTABILITY, EXCLUSIVITY, OR RESULTS OBTAINED FROM USE OF THE MATERIAL. CARNEGIE MELLON UNIVERSITY DOES NOT&#xA;MAKE ANY WARRANTY OF ANY KIND WITH RESPECT TO FREEDOM FROM PATENT, TRADEMARK, OR COPYRIGHT INFRINGEMENT.&#xA;&#xA;This program and the accompanying materials are made available under the terms of the Eclipse Public License 2.0&#xA;which is available at https://www.eclipse.org/legal/epl-2.0/&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Created, in part, with funding and support from the United States Government. (see Acknowledgments file).&#xA;&#xA;This program includes and/or can make use of certain third party source code, object code, documentation and other&#xA;files (&quot;Third Party Software&quot;). The Third Party Software that is used by this program is dependent upon your system&#xA;configuration. By using this program, You agree to comply with any and all relevant Third Party Software terms and&#xA;conditions contained in any such Third Party Software or separate license file distributed with such Third Party&#xA;Software. The parties who own the Third Party Software (&quot;Third Party Licensors&quot;) are intended third party benefici-&#xA;aries to this license with respect to the terms applicable to their Third Party Software. Third Party Software li-&#xA;censes only apply to the Third Party Software and not any other portion of this program or this program as a whole.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge.errormodel.feature.feature.group' version='5.0.0.v20211129-1541'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.xtext.aadl2.errormodel' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.lang' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views.properties.tabbed' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge.swt' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge.errormodel' range='[2.1.0.v20211129-1541,2.1.0.v20211129-1541]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge.errormodel.feature.feature.jar' range='[5.0.0.v20211129-1541,5.0.0.v20211129-1541]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        Copyright (c) 2004-2021 Carnegie Mellon University and others. (see Contributors file).
      </copyright>
    </unit>
    <unit id='org.osate.ge.feature.feature.group' version='5.2.0.v20220201-1822' singleton='false'>
      <update id='org.osate.ge.feature.feature.group' range='[0.0.0,5.2.0.v20220201-1822)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='OSATE Graphical Editor'/>
        <property name='org.eclipse.equinox.p2.description' value='Graphical Editor for AADL'/>
        <property name='org.eclipse.equinox.p2.provider' value='The University of Alabama in Huntsville'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.osate'/>
        <property name='maven-artifactId' value='org.osate.ge.feature'/>
        <property name='maven-version' value='5.2.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Copyright (c) 2004-2021 Carnegie Mellon University and others. (see Contributors file).&#xA;All Rights Reserved.&#xA;&#xA;NO WARRANTY. ALL MATERIAL IS FURNISHED ON AN &quot;AS-IS&quot; BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY&#xA;KIND, EITHER EXPRESSED OR IMPLIED, AS TO ANY MATTER INCLUDING, BUT NOT LIMITED TO, WARRANTY OF FITNESS FOR PURPOSE&#xA;OR MERCHANTABILITY, EXCLUSIVITY, OR RESULTS OBTAINED FROM USE OF THE MATERIAL. CARNEGIE MELLON UNIVERSITY DOES NOT&#xA;MAKE ANY WARRANTY OF ANY KIND WITH RESPECT TO FREEDOM FROM PATENT, TRADEMARK, OR COPYRIGHT INFRINGEMENT.&#xA;&#xA;This program and the accompanying materials are made available under the terms of the Eclipse Public License 2.0&#xA;which is available at https://www.eclipse.org/legal/epl-2.0/&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Created, in part, with funding and support from the United States Government. (see Acknowledgments file).&#xA;&#xA;This program includes and/or can make use of certain third party source code, object code, documentation and other&#xA;files (&quot;Third Party Software&quot;). The Third Party Software that is used by this program is dependent upon your system&#xA;configuration. By using this program, You agree to comply with any and all relevant Third Party Software terms and&#xA;conditions contained in any such Third Party Software or separate license file distributed with such Third Party&#xA;Software. The parties who own the Third Party Software (&quot;Third Party Licensors&quot;) are intended third party benefici-&#xA;aries to this license with respect to the terms applicable to their Third Party Software. Third Party Software li-&#xA;censes only apply to the Third Party Software and not any other portion of this program or this program as a whole.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge.feature.feature.group' version='5.2.0.v20220201-1822'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='27'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.transaction' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ui' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.xtext.aadl2.properties' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2.modelsupport' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.xtext.aadl2.properties.ui' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.xtext.aadl2.ui' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views.properties.tabbed' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.services' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ui' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.contexts' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge' range='[3.0.1.v20211129-1541,3.0.1.v20211129-1541]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge.doc' range='[1.0.7.v20211129-1541,1.0.7.v20211129-1541]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge.diagram' range='[2.0.2.v20210113-1653,2.0.2.v20210113-1653]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge.gef' range='[1.2.0.v20220201-1822,1.2.0.v20220201-1822]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge.gef.ui' range='[1.0.1.v20211129-1541,1.0.1.v20211129-1541]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge.swt' range='[2.0.0.v20210812-1614,2.0.0.v20210812-1614]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ge.feature.feature.jar' range='[5.2.0.v20220201-1822,5.2.0.v20220201-1822]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        Copyright (c) 2004-2021 Carnegie Mellon University and others. (see Contributors file).
      </copyright>
    </unit>
    <unit id='org.osate.utils.feature.feature.group' version='2.0.1.v20210925-2005' singleton='false'>
      <update id='org.osate.utils.feature.feature.group' range='[0.0.0,2.0.1.v20210925-2005)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='AADL-Utils'/>
        <property name='org.eclipse.equinox.p2.description' value='TELECOM Paristech AADL V2 plugin utils for OSATE2.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://aadl.telecom-paristech.fr/'/>
        <property name='org.eclipse.equinox.p2.provider' value='TELECOM ParisTech'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.osate'/>
        <property name='maven-artifactId' value='org.osate.utils.feature'/>
        <property name='maven-version' value='2.0.1-SNAPSHOT'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osate.utils.feature.feature.group' version='2.0.1.v20210925-2005'/>
      </provides>
      <requires size='6'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='3.7.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext' range='2.2.1'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.xtext.aadl2.properties' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.utils' range='[2.0.1.v20210925-2005,2.0.1.v20210925-2005]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.utils.feature.feature.jar' range='[2.0.1.v20210925-2005,2.0.1.v20210925-2005]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.eclipse.org/org/documents/epl-v10.ph' url='http://www.eclipse.org/org/documents/epl-v10.ph'>
          This program is free software: you can redistribute it and/or modify  it under the terms of the Eclipse Public License as published by Eclipse, either version 1.0 of the License, or (at your option) any later version.&#xA;This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the Eclipse Public License for more details.&#xA;You should have received a copy of the Eclipse Public License along with this program. If not, see http://www.eclipse.org/org/documents/epl-v10.ph
        </license>
      </licenses>
      <copyright uri='http://aadl.telecom-paristech.fr/' url='http://aadl.telecom-paristech.fr/'>
        AADL-Utils&#xA;Copyright © 2012 TELECOM ParisTech and CNRS&#xA;TELECOM ParisTech/LTCI
      </copyright>
    </unit>
    <unit id='org.osate.xtext.aadl2.errormodel.feature.feature.group' version='9.0.2.v20220203-1935' singleton='false'>
      <update id='org.osate.xtext.aadl2.errormodel.feature.feature.group' range='[0.0.0,9.0.2.v20220203-1935)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='Error Model Annex V2 for OSATE2'/>
        <property name='org.eclipse.equinox.p2.description' value='Provide support for Error-Model Annex version 2'/>
        <property name='org.eclipse.equinox.p2.provider' value='CMU-SEI'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.osate'/>
        <property name='maven-artifactId' value='org.osate.xtext.aadl2.errormodel.feature'/>
        <property name='maven-version' value='9.0.2-SNAPSHOT'/>
        <property name='df_LT.license' value='Copyright (c) 2004-2021 Carnegie Mellon University and others. (see Contributors file).&#xA;All Rights Reserved.&#xA;&#xA;NO WARRANTY. ALL MATERIAL IS FURNISHED ON AN &quot;AS-IS&quot; BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY&#xA;KIND, EITHER EXPRESSED OR IMPLIED, AS TO ANY MATTER INCLUDING, BUT NOT LIMITED TO, WARRANTY OF FITNESS FOR PURPOSE&#xA;OR MERCHANTABILITY, EXCLUSIVITY, OR RESULTS OBTAINED FROM USE OF THE MATERIAL. CARNEGIE MELLON UNIVERSITY DOES NOT&#xA;MAKE ANY WARRANTY OF ANY KIND WITH RESPECT TO FREEDOM FROM PATENT, TRADEMARK, OR COPYRIGHT INFRINGEMENT.&#xA;&#xA;This program and the accompanying materials are made available under the terms of the Eclipse Public License 2.0&#xA;which is available at https://www.eclipse.org/legal/epl-2.0/&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Created, in part, with funding and support from the United States Government. (see Acknowledgments file).&#xA;&#xA;This program includes and/or can make use of certain third party source code, object code, documentation and other&#xA;files (&quot;Third Party Software&quot;). The Third Party Software that is used by this program is dependent upon your system&#xA;configuration. By using this program, You agree to comply with any and all relevant Third Party Software terms and&#xA;conditions contained in any such Third Party Software or separate license file distributed with such Third Party&#xA;Software. The parties who own the Third Party Software (&quot;Third Party Licensors&quot;) are intended third party benefici-&#xA;aries to this license with respect to the terms applicable to their Third Party Software. Third Party Software li-&#xA;censes only apply to the Third Party Software and not any other portion of this program or this program as a whole.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osate.xtext.aadl2.errormodel.feature.feature.group' version='9.0.2.v20220203-1935'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='41'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2.modelsupport' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.ui' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.xtext.aadl2.errormodel' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.xtext.aadl2.properties' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.log4j' range='1.2.15'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore' range='2.7.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common' range='2.7.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.antlr.runtime' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='3.7.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.core' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='3.7.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.annexsupport' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.uml2.codegen.ecore' range='1.9.100'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xbase.lib' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ui' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.editors' range='3.7.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide' range='3.7.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ui.shared' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.builder' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.common.types.ui' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.xtext.aadl2.properties.ui' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.transaction' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.util' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.common.types' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2.errormodel.analysis' range='[1.1.6.v20220120-2009,1.1.6.v20220120-2009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.xtext.aadl2.errormodel' range='[6.2.2.v20220203-1935,6.2.2.v20220203-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.xtext.aadl2.errormodel.ui' range='[6.2.2.v20220203-1935,6.2.2.v20220203-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2.errormodel.contrib' range='[1.0.7.v20220120-2009,1.0.7.v20220120-2009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2.errormodel.faulttree' range='[6.1.0.v20210925-2005,6.1.0.v20210925-2005]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2.errormodel.faulttree.design' range='[1.1.5.v20210925-2005,1.1.5.v20210925-2005]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2.errormodel.faulttree.edit' range='[6.1.0.v20210925-2005,6.1.0.v20210925-2005]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2.errormodel.faulttree.generation' range='[1.0.7.v20211221-1532,1.0.7.v20211221-1532]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2.errormodel.propagationgraph' range='[6.2.1.v20211021-1926,6.2.1.v20211021-1926]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.aadl2.errormodel.help' range='[1.0.3.v20211206-1639,1.0.3.v20211206-1639]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.xtext.aadl2.errormodel.edit' range='[1.0.1.v20210925-2005,1.0.1.v20210925-2005]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.xtext.aadl2.errormodel.feature.feature.jar' range='[9.0.2.v20220203-1935,9.0.2.v20220203-1935]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        Copyright (c) 2004-2021 Carnegie Mellon University. All rights reserved.
      </copyright>
    </unit>
    <unit id='osate2' version='2.10.2.vfinal'>
      <update id='osate2' range='0.0.0' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='OSATE2'/>
        <property name='org.eclipse.equinox.p2.type.product' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='osate2' version='2.10.2.vfinal'/>
      </provides>
      <requires size='30'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingosate2.application' range='[2.10.2.vfinal,2.10.2.vfinal]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.discovery.feature.feature.group' range='[1.2.800.v20200916-1234,1.2.800.v20200916-1234]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.feature.group' range='[5.11.0.202103091610-r,5.11.0.202103091610-r]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ease.lang.unittest.feature.feature.group' range='[0.7.0.I201906281229,0.7.0.I201906281229]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ease.modules.feature.feature.group' range='[0.7.0.I201907160756,0.7.0.I201907160756]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.executable.feature.group' range='[3.8.1100.v20210209-1541,3.8.1100.v20210209-1541]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.core.feature.feature.group' range='[9.1.0.v20220203-1935,9.1.0.v20220203-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.plugins.feature.feature.group' range='[6.1.2.v20220120-2009,6.1.2.v20220120-2009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.group' range='[4.19.0.v20210303-1800,4.19.0.v20210303-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ease.ui.feature.feature.group' range='[0.7.0.I201907161104,0.7.0.I201907161104]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.fx.runtime.min.feature.feature.group' range='[3.7.0.202010120720,3.7.0.202010120720]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sirius.runtime.ide.ui.feature.group' range='[6.4.2.202103091337,6.4.2.202103091337]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.py4j.feature.feature.group' range='[0.10.9.3-bnd-B70oWw,0.10.9.3-bnd-B70oWw]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingosate2.configuration' range='[2.10.2.vfinal,2.10.2.vfinal]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osate.dependencies.birt.feature.group' range='[4.9.0.v20200203-1545,4.9.0.v20200203-1545]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.elk.algorithms.feature.feature.group' range='[0.7.1,0.7.1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.context_feature.feature.group' range='[3.25.2.v20200828-1617,3.25.2.v20200828-1617]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.justj.openjdk.hotspot.jre.full.stripped.feature.group' range='[11.0.13.v20211116-1829,11.0.13.v20211116-1829]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsemantics.runtime.feature.feature.group' range='[1.20.0.v20210401-0731,1.20.0.v20210401-0731]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='openjfx.swing.feature.feature.group' range='[16.0.0.202104071212,16.0.0.202104071212]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ease.feature.feature.group' range='[0.7.0.I201907120558,0.7.0.I201907120558]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.elk.feature.feature.group' range='[0.7.1,0.7.1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='openjfx.swt.feature.feature.group' range='[16.0.0.202104071212,16.0.0.202104071212]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ease.lang.python.py4j.feature.feature.group' range='[0.7.0.I201907020902,0.7.0.I201907020902]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ease.lang.scriptarchive.feature.feature.group' range='[0.7.0.I201906281229,0.7.0.I201906281229]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='openjfx.standard.feature.feature.group' range='[16.0.0.202104071212,16.0.0.202104071212]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='osgi.ee' name='JavaSE' range='0.0.0'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='configure'>
            org.eclipse.equinox.p2.touchpoint.natives.remove(path:${installFolder}/launcher);org.eclipse.equinox.p2.touchpoint.natives.remove(path:${installFolder}/launcher.exe);org.eclipse.equinox.p2.touchpoint.natives.remove(path:${installFolder}/eclipsec.exe-*.p2bu);org.eclipse.equinox.p2.touchpoint.natives.remove(path:${installFolder}/eclipsec.exe);org.eclipse.equinox.p2.touchpoint.natives.remove(path:${installFolder}/Eclipse.app);org.eclipse.equinox.p2.touchpoint.natives.remove(path:${installFolder}/readme);org.eclipse.equinox.p2.touchpoint.natives.remove(path:${installFolder}/notice.html);org.eclipse.equinox.p2.touchpoint.natives.remove(path:${installFolder}/.eclipseproduct);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='osate2.executable.win32.win32.x86_64' version='2.10.2.vfinal'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='osate2.executable.win32.win32.x86_64' version='2.10.2.vfinal'/>
        <provided namespace='toolingosate2' name='osate2.executable' version='2.10.2.vfinal'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='osate2.executable.win32.win32.x86_64' version='2.10.2.vfinal'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
  </units>
  <iusProperties size='17'>
    <iuProperties id='SharedProfile_DefaultProfile' version='1.0.0.1768296019734'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.equinox.executable_root.win32.win32.x86_64' version='3.8.1100.v20210209-1541'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64' value='/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64/eclipsec.exe|/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64/launcher.exe|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.pde.feature.group' version='3.14.700.v20210303-1800'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.pde.source.feature.group' version='3.14.700.v20210303-1800'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.platform_root' version='4.19.0.v20210303-1800'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64' value='/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64/.eclipseproduct|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.rcp_root' version='4.19.0.v20210303-1800'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64' value='/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64/readme|/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64/readme/readme_eclipse.html|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.osate.alisa.workbench.sdk.feature.group' version='7.1.1.v20220203-1935'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.osate.ba.feature.feature.group' version='5.2.0.v20220120-2009'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.osate.core.feature_root' version='9.1.0.v20220203-1935'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64' value='/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64/ACKNOWLEDGEMENTS|/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64/LICENSE|/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64/COPYRIGHT|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.osate.examples.feature.feature.group' version='1.0.1.v20220206-1739'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.osate.ge.ba.feature.feature.group' version='2.0.1.v20211221-1532'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.osate.ge.errormodel.feature.feature.group' version='5.0.0.v20211129-1541'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.osate.ge.feature.feature.group' version='5.2.0.v20220201-1822'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.osate.utils.feature.feature.group' version='2.0.1.v20210925-2005'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.osate.xtext.aadl2.errormodel.feature.feature.group' version='9.0.2.v20220203-1935'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='osate2' version='2.10.2.vfinal'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='osate2.executable.win32.win32.x86_64' version='2.10.2.vfinal'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64' value='/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64/META-INF/MANIFEST.MF|/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64/META-INF/CARNEGIE.SF|/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64/META-INF/CARNEGIE.RSA|/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64/osate.exe|/home/lw/git/osate_2.10.2-build/osate2/core/org.osate.build.product/target/products/osate2/win32/win32/x86_64/osatec.exe|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
